const FrameStyles = {
  FramesContainer: {
    overflowX: "scroll",
    display: "flex",
    flexDirection: "row"
  },
  newFrameButton: {
    marginTop: "10px",
    marginBottom: "25px",
    paddingRight: "25px",
    paddingLeft: "25px"
  },
}

export default FrameStyles
const AppStyles = {
  SegmentBGColor: {
    backgroundColor: "#333333"
  },
  FrameContainerStyle: {
    marginTop: "15px"
  },
  ToolBoxSegmentStyles: {
    display: "inline-block",
    padding: "5%",
    width: "100%",
    height: "auto"
  },
}

export default AppStyles
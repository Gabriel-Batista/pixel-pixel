const ToolBoxStyles = {
  colorPicker: {
    margin: "0 auto"
  },
}

export default ToolBoxStyles
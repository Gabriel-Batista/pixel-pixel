export const fetchConsts = {
  API: "pixel-pixel.us-west-2.elasticbeanstalk.com",
  HEADERS: {
    "Content-Type": "application/json",
    Accept: "application/json"
  }
};
